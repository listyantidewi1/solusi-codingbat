CodingBat Python Solutions
==========================

Pretty self explanatory, the solutions I came up with when I did the problem
sets. There are probably better solutions, comments are welcome.

Cheating
--------

Nobody likes a cheater and you will eventually get caught, so use this for 
reference only and make sure you at least understand what is being done.